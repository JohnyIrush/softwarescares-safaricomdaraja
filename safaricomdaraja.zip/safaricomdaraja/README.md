# softwarescares-safaricomdaraja
 Safaricom daraja api integration for accessing mpesa services
