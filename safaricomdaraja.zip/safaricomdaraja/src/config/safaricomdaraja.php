<?php

//-- Daraja api configuration credentials

return array(
    'MPESA' => array(
        "ENV" => "development",
        "CONSUMER_KEY" => "78AgGOgdMCFMq7cBCnnRoQLQS7wjbKjU",
        "CONSUMER_SECRET" => "qZe3hE1rFndU8fyo",
        "BUSINESSSHORTCODE" => "174379",
        "SHORTCODE" => "",
        "PASSEKEY" => "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919",
        "APP_DOMAIN_URL" =>"https://0726-154-122-167-19.ngrok.io",
        "COMMANDID" => "",

    ),
);